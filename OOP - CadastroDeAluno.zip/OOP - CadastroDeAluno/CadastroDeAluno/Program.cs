﻿using CadastroDeAluno;
using CadastroDeAluno.Models;
using CadastroDeAluno.DAO;
using Mysqlx.Crud;
Connection.Start();



// PADRÃO MVC (MODEL VIEW CONTROL)
/* model = modelo de objetos;
 * viwers = 
 * control = controles
 * 
 */
// PADRÃO DAO (DATA ACCESS OBJECT)

try
{
    /*Console.WriteLine("---Cadastro de Aluno---");
    Student stdnt = new Student();
    Console.Write("Nome: ");
    stdnt.FullName = Console.ReadLine()!;
    Console.Write("CPF: ");
    stdnt.CPF = Console.ReadLine()!;
    Console.Write("Telefone: ");
    stdnt.Email = Console.ReadLine()!;
    Console.Write("Email: ");
    stdnt.Email = Console.ReadLine()!;
    Console.WriteLine("Data de Nascimento");
    Console.Write("Dia: "); int dd = int.Parse(Console.ReadLine()!);
    Console.Write("Mês: "); int mm = int.Parse(Console.ReadLine()!);
    Console.Write("Ano: "); int yy = int.Parse(Console.ReadLine()!);
    stdnt.Birthdate = new DateOnly(yy, mm, dd);
    Console.ReadKey();

    StudentDAO stdntDAO = new StudentDAO();
    stdntDAO.Insert(stdnt);
    */

    Student s = new Student();
    s.FullName = "Vinnie Pine";
    s.CPF = "85329401291";
    s.Email = "vinnie.pine@mail.com";
    s.Phone = "69999018504";
    s.Birthdate = new DateOnly(1994,10,01);

    StudentDAO sDAO = new StudentDAO();
    sDAO.Insert(s);

}catch(Exception es)
{
    Console.WriteLine(es.Message);
}


/*
    --- SQL usado ---
CREATE DATABASE hogwarts_bd;
USE hogwarts_bd;
CREATE TABLE students(
	id	INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(50),
    cpf VARCHAR(11),
    email VARCHAR(70),
    phone VARCHAR(15),
    birthdate DATE
);

SELECT * FROM STUDENTS;
 
 */

/* -- Plataformas para usar na apresentação --
 * Blazer
 * WindowsForms
 * WPF
 * DotNet
*/