﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CadastroDeAluno.Models;
using MySql.Data.MySqlClient;

namespace CadastroDeAluno.DAO
{
    // CRUD
    internal class StudentDAO
    {
        public void Insert(Student student)
        {
            try
            {
                string birthdate = student.Birthdate.ToString("yyyy-MM-dd");
                string sqlQuery = "INSERT INTO students (full_name, cpf, email, phone, birthdate) VALUES (@name, @cpf, @mail, @phone, @bd)";
                MySqlCommand cmd = new MySqlCommand(sqlQuery, Connection.Start());
                cmd.Parameters.AddWithValue("@name", student.FullName);
                cmd.Parameters.AddWithValue("@cpf", student.CPF);
                cmd.Parameters.AddWithValue("@mail", student.Email);
                cmd.Parameters.AddWithValue("@phone", student.Phone);
                cmd.Parameters.AddWithValue("@bd", birthdate);
                cmd.ExecuteNonQuery();
                Console.WriteLine("Aluno cadastrado com sucesso!");
            }
            catch(Exception ex)
            {
                throw new Exception($"Erro ao cadastrar o aluno! {ex.Message}");
            }
            finally
            {
                Connection.End();
            }
        }
        public void Delete(Student student) 
        {
            try
            {
                string sql = "DELETE FROM students WHERE id = @id";
                MySqlCommand cmd= new MySqlCommand(sql, Connection.Start());
                cmd.Parameters.AddWithValue("@id", student.ID);
                cmd.ExecuteNonQuery();
                Console.WriteLine("Aluno excluído com sucesso!");
                Connection.End();
            }
            catch(Exception ex)
            {
                throw new Exception($"Erro ao excluir o aluno! {ex.Message}");
            }
        }
        public List<Student> List()
        {
            List<Student> studentsList = new List<Student>();

            try
            {
                string sql = "SELECT * FROM students ORDER BY full_name";
                MySqlCommand cmd = new MySqlCommand(sql, Connection.Start());
                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Student stdnt = new Student();
                        stdnt.ID = reader.GetInt32("id");
                        stdnt.FullName = reader.GetString("full_name");
                        stdnt.Email = reader.GetString("email");
                        stdnt.Phone = reader.GetString("phone");
                        stdnt.CPF = reader.GetString("cpf");
                        stdnt.Birthdate = DateOnly.FromDateTime(reader.GetDateTime("birthdate"));
                        studentsList.Add(stdnt);
                    }
                    Connection.End(); // Fechar a conexão após a leitura
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Erro ao excluir o aluno! {ex.Message}");
            }
            return studentsList;
        }
        public void Update() { }
    }
}
