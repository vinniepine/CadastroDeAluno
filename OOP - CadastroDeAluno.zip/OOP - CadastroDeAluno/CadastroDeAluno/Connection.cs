﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CadastroDeAluno
{
    internal class Connection
    {
        static MySqlConnection _connection; // Declaração de objeto da classe 'MySqlConnection' responsável por controlar a conexão com a base;

        public static MySqlConnection Start()
        {
            try
            {
                /* 
                    Configuração da conexão com o banco de dados:
                    - SERVER irá definir o servidor em que está o banco de dados;
                    - PORT irá definir a entrada no servidor em que está BD. 
                      É o número em frente ao localhost, no home do MySQL
                    - UID irá definir o nome do usuário do banco de dados;
                    - PWD irá definir a senha do usuário no SGBD;
                    - DataBase irá definir o nome da base de dados.
                */
                string newConnection = "server=localhost;port=3360;uid=root;pwd=root;database=hogwarts_bd";
                _connection = new MySqlConnection(newConnection); // instanciando o objeto da classe 'MySqlConnection';
                _connection.Open();
                Console.WriteLine("Conexão realizada com sucesso!");
            }
            catch (Exception ex)
            {
                // Console.WriteLine("Erro ao realizar a conexão com a base de dados!");
                throw new Exception("Erro ao realizar a conexão com a base de dados!" + ex.Message);

            }
            return _connection;
        }

        public static void End()
        {
            _connection.Close();
        }
    }
}
